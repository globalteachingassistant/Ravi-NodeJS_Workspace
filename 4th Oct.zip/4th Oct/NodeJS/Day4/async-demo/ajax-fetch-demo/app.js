var http = require('http');
var express = require('express');

var app = express();
var server = http.createServer(app);

app.use(express.static('public'));

server.listen(4200, function() {
    console.log('Server started!')
})