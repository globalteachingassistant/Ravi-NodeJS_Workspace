const http = require('http')
const port = process.env.PORT || 4200
const server = http.createServer(function(req, res) {
    res.end('TEST')
})

server.listen(port, () => console.log('server started ' + port))