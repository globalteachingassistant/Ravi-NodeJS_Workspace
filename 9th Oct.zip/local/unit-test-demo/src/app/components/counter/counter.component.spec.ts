import { CounterComponent } from './counter.component'

describe('CounterComponent', () => {
  let counter = null

  beforeEach(() => {
    counter = new CounterComponent()
  })

  it('A Gets initialized by zero', () => {
    expect(counter.value).toBe(0)
  })

  it('B Gets incremented Correctly', () => {
    counter.incr();
    counter.incr();
    counter.incr();
    counter.incr();

    expect(counter.value).toBe(4)
  })

  it('C Gets Decremented correctly', () => {
    counter.decr()
    counter.decr()
    counter.decr()
    counter.decr()

    expect(counter.value).toBe(-4)
  })
})

// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { CounterComponent } from './counter.component';

// describe('CounterComponent', () => {
//   let component: CounterComponent;
//   let fixture: ComponentFixture<CounterComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ CounterComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(CounterComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
