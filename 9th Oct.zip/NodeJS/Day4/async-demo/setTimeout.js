setTimeout(function() {
    console.log('Hello')
})

setTimeout(function() {
    console.log('TEST')
})

console.log('Bye');



