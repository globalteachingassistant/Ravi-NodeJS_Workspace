var http = require('http');
var url = require('url');

var server = http.createServer(function(req, res) {
    var segments = url.parse(req.url)
    switch (segments.pathname) {
        case '/':
        case '/home':
            res.end('Home Page')
            break;
            
        case '/about':
            res.end('About Us')
            break
        
        case '/services':
            res.end('Services')
            break
        
        default:
            res.end('404 Page Not Found.')
    }
});

server.listen(4200, function() {
    console.log('SERVER Started...')
})