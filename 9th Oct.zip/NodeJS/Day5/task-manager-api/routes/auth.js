var express = require('express');
var router = express.Router();

router.post('/login', function(req, res) {
    res.send('Login POST works!');
});

router.post('/register', function(req, res) {
    res.send('Reg POST works!');
});

module.exports = router;