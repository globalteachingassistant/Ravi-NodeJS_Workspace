import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-task-nav',
  templateUrl: './task-nav.component.html',
  styleUrls: ['./task-nav.component.css']
})
export class TaskNavComponent implements OnInit {

  constructor(
      private authService: AuthService,
      private router: Router
  ) { }

  ngOnInit() {
  }

  logout() {
      this.authService.logout();
      this.router.navigate(['/']);
  }
}
