var express = require('express');

var tasksRouter = require('./routes/tasks');

var app = express();

app.use('/', tasksRouter);

module.exports = app;