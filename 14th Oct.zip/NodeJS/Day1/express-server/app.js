var express = require('express')
var PORT = 4200
var app = express()

app.get('/', function(req, res) {
    res.send('Express Works!')
})

app.listen(PORT, function() {
    console.log('Server Running on :: ' + PORT)
})