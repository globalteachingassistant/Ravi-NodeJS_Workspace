import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuard } from 'src/app/guards/auth.guard'

import { LoginComponent } from '../components/login/login.component'
import { TaskManagerComponent } from '../components/task-manager/task-manager.component'
import { TaskFormComponent } from '../components/task-manager/task-form/task-form.component'
import { TaskListComponent } from '../components/task-manager/task-list/task-list.component'
import { TaskDetailComponent } from '../components/task-manager/task-detail/task-detail.component'
import { PageNotFoundComponent } from '../components/page-not-found/page-not-found.component'

const routes: Routes = [
    { path: '', redirectTo: '/login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent },
    { 
        path: 'tasks', 
        component: TaskManagerComponent, 
        children: [
            { path: '', redirectTo: '/tasks/list', pathMatch: 'full' }, 
            { path: 'list', component: TaskListComponent },
            { path: 'add', component: TaskFormComponent }, 
            { path: 'detail/:id', component: TaskDetailComponent }
        ],
        canActivate: [AuthGuard]
    },
    { path: '**', component: PageNotFoundComponent }
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
