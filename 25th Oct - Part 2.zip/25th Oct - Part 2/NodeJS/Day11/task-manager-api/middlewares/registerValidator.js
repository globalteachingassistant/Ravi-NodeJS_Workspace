function registerValidator(req, res, next) {
    //TODO: name, email, username, password
    next();
}

module.exports = registerValidator;