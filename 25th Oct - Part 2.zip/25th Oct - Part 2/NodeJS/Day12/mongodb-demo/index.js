//Include Mongoose
var mongoose = require('mongoose')

//Connect to our DB
mongoose.connect(
    'mongodb://localhost:27017/taskManager', 
    { useNewUrlParser: true, useUnifiedTopology: true },
    function(err) {
        if(!err) {
            console.log('DB Connected!');
            // mongoose.disconnect();
        }
    }
);

//Create a Schema (as mongodb doesn't enforce a schema)
var TasksSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String }, 
    completed: { type: Boolean, default: false }
}, {
    timestamps: true
});

//Create a model with the above Schema
var Task = mongoose.model('task', TasksSchema);


var task = new Task();
task.title = 'Learn Mongoose 2';
task.description ='This is to learn Mongoose';

task.save()
.then(function(){
    Task.find().then(function(data){
    console.log(data);
    }).catch(function(err){
        console.log(err)
    })
}).catch(function(err){
    console.log(err)
})


