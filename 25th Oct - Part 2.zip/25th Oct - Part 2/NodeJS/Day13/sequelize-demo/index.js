var Sequelize = require('sequelize');

var sequelize = new Sequelize({
    host: 'localhost',
    dialect: 'sqlite',
    storage: __dirname + '/db.sqlite'
});

var Task = sequelize.define('task', {
    title: {
        type: Sequelize.STRING
    },
    description: {
        type: Sequelize.STRING
    },
    completed: {
        type: Sequelize.BOOLEAN,
        default: true
    }
});

Task.sync()
    .then(function() {
        console.log('Task Table Created!')
        return Task.create({
            title: 'Test123',
            description: 'Test123'
        })
    })
    .then(function(data) {
        console.log('Task Created!');
    })
    .then(async function() {
        var tasks = await Task.findAll()
        console.log(tasks);
    })