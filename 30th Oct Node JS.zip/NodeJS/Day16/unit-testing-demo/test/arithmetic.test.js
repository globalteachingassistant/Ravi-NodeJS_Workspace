var expect = require('chai').expect;

var add = require('../arithmetic').add;

describe('Arithmetic', function() {
    it('Adds two numbers correctly', function() {
        expect(add(1,2)).to.equal(3)
    })    
})

