exports.add = function (a, b) {
    return a + b;
}

exports.div = function(a, b) {
    return a / b;
}