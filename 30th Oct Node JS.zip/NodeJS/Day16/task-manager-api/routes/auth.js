var express = require('express');
var router = express.Router();

var loginValidator = require('../middlewares/loginValidator')
var registerValidator = require('../middlewares/registerValidator')

var AuthController = require('../controllers/AuthController')

router.post('/login', [
    loginValidator, 
    AuthController.login
]);

router.post('/register', [
    registerValidator,
    AuthController.register
]);

module.exports = router;