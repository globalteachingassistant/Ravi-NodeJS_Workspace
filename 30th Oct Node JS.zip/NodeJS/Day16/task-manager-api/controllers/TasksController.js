var Task = require('../models/Task');

exports.addTask = function(req, res) {
    var data = req.body;
    var task = new Task();
    
    task.title = data.title;
    task.description = data.description;
    
    task.save()
        .then(function(data) {
            res.json(data);
        })
        .catch(function(err) {
            res.status(500).json({
                msg: 'Something went wrong.'
            })
        })
}

exports.getTasks = function(req, res) {
    Task.find()
        .then(function(data) {
            res.json(data);
        })
        .catch(function() {
            res.status(500).json({
                msg: 'Something went wrong.'
            })
        })
}

exports.getSingleTask = function(req, res) {
    var id = req.params.id;
    
    Task.findById(id)
        .then(function(data) {
            if(data) {
                res.json(data)
            } else {
                res.status(404).json({
                    msg: 'Task Not Found'
                })
            }
        })
        .catch(function() {
            res.status(500).json({
                msg: 'Something went wrong'
            })
        })
}

exports.removeTask = function(req, res) {
    var id = req.params.id;
    
    Task.findByIdAndRemove(id)
        .then(function(data) {
            if(data) {
                res.json({})
            } else {
                res.status(404).json({
                    msg: 'Task Not Found'
                })
            }
        })
        .catch(function() {
            res.status(500).json({
                msg: 'Something Went wrong.'
            })
        })
}

exports.updateTask = async function(req, res) {
    var id = req.params.id;
    var data = req.body;
    
    var task = await Task.findById(id);
    
    if(task) {
        task.title = data.title;
        task.description = data.description;
        task.completed = data.completed;
    
        var updated = await task.save();
    
        if(updated) {
            res.json(updated);
        } else {
            res.status(500).json({
                msg: 'Something went wrong'
            })
        }
    } else {
        res.status(404).json({
            msg: 'Task Not Found'
        })
    }
}

exports.markAsComplete = async function(req, res) {
    var id = req.params.id;
    
    var task = await Task.findById(id);
    
    if(task) {
        task.completed = !task.completed;
        var updated  = await task.save()
        res.json(updated)
    }
}