module.exports = {
    uri: process.env.CONNECTION_URI || 'mongodb://'
}