var chai = require('chai');
var expect = chai.expect;
var chaiHttp = require('chai-http');
var app = require('../app')

chai.use(chaiHttp);

it('gets a proper response', function() {
chai.request(app)
    .get('/')
    .end(function(err, res) {
        // console.log(err, res)
        expect(res).to.have.status(200)
    });    
})
