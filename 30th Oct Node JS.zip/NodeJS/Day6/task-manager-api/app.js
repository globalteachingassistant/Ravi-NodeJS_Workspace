var express = require('express');

var tasksRouter = require('./routes/tasks');
var authRouter = require('./routes/auth');

var app = express();


app.use('/tasks', tasksRouter);
app.use('/', authRouter);

module.exports = app;