var http = require('http')
var express = require('express')
var socketio = require('socket.io')

var app = express()
var server = http.createServer(app)
var io = socketio(server)

var users = [];

io.on('connection', function(socket) {
    console.log('User Connected!')
    socket.on('onClientMsg', function(msg) {
        io.emit('onServerMsg', msg)
    })
    
    socket.on('onUsername', function(username) {
        users.push(username)
        io.emit('onUsers', users)
    })
})

app.use(express.static('public'))

server.listen(4200, function() {
    console.log('server started!')
})