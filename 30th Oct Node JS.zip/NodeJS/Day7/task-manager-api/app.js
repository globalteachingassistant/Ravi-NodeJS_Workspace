var express = require('express');
var bodyParser = require('body-parser');

var tasksRouter = require('./routes/tasks');
var authRouter = require('./routes/auth');

var app = express();

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
// parse application/json
app.use(bodyParser.json())

app.use('/tasks', tasksRouter);
app.use('/', authRouter);

module.exports = app;