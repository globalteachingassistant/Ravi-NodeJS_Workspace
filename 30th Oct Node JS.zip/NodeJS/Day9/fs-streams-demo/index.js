var fs = require('fs');

// var stream = fs.createReadStream('../Topics.txt', { start: 10, end: 200 });
var stream = fs.createReadStream('file_example.mp4');

// fs.readFile('../Topics.txt', function(err, buffer) {
//     console.log('Read File', buffer.length);
// })

stream.on('data', function(buffer) {
    // console.log('Read Stream', buffer.toString(), buffer.length);
    console.log('on data event', buffer.length);
});

stream.on('end', function() {
   console.log('Streaming ended.');
});