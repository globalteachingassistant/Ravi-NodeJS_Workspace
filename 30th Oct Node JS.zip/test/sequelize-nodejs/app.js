var Sequelize =  require('sequelize')

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: 'data/db.sqlite'
});

const Model = Sequelize.Model;
class User extends Model {}
User.init({
  // attributes
  firstName: {
    type: Sequelize.STRING,
    allowNull: false
  },
  lastName: {
    type: Sequelize.STRING
    // allowNull defaults to true
  }
}, {
  sequelize,
  modelName: 'user'
  // options
});

// Note: using `force: true` will drop the table if it already exists
User.sync({ force: true }).then(() => {
  // Now the `users` table in the database corresponds to the model definition
 // Create a new user
    User.create({ firstName: "Jane", lastName: "Doe" }).then(jane => {
      console.log("Jane's auto-generated ID:", jane.id);
    });
    
    // Find all users
    User.findAll().then(users => {
      console.log("All users:", JSON.stringify(users, null, 4));
    });
});



