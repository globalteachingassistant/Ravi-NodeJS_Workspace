var fs = require('fs')
var http = require('http')
var path = require('path')

var server = http.createServer(function(req, res) {
    var filePath = 'file_example.mp4'
    console.log(filePath)
    var stat = fs.statSync(filePath)
    var fileSize = stat.size
    
    res.setHeader('Content-Length', fileSize)
    res.setHeader('Content-type', 'video/mp4')
    
    fs.createReadStream(filePath).pipe(res)
})

server.listen(4200, function() { console.log('server listening')} )