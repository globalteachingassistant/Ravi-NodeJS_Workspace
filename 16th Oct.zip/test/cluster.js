var cluster = require('cluster');
var http = require('')

if(cluster.isMaster) {
    cluster.fork();    
} else {
    
}
