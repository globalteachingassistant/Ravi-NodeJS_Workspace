/**
 * http://es6-features.org/#PromiseUsage
  resolve() - .then()
  reject()  - .catch()
*/

const promise = new Promise((resolve, reject) => {
  setTimeout(() => resolve(), 3000)
})

promise
  .then(() => console.log('Inside Then.'))
  .then(() => console.log('TEST'))
  .then(() => console.log('hi'))
  .catch(() => console.log('Inside Catch.'))

console.log('Hello!!!')