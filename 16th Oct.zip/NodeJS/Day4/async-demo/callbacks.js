function sayHelloAfter1Sec(user, callback) { //callback = function() { console.log() }
    setTimeout(function() {
        console.log('Hello ' + user + '!!')
        callback()
    }, 1000);
}

sayHelloAfter1Sec('Ravi', function() { console.log('Hello is Done!')});

/*
    //callback

    get('countries', function() {
        //populate the countries dropdown.
        
        get('states', function() {
            //populate states dropdown
            
            get('cities', function() {
                
                //cities dropdown
                get('areas', function(){
                    //populate the areas on dropdown.
                    
                })
            })
        })
    })
    
    //promises
    get('countries')
        .then()
        .then()
        .then()
        .then()
        .catch()
    
*/