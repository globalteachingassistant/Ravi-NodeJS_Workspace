var express = require('express');
var router = express.Router();

router.get('/', function(req, res) {
  res.send('Tasks GET Works!');
});

router.post('/', function(req, res) {
  res.send('Tasks POST Works!');  
});

router.put('/', function(req, res) {
  res.send('Tasks PUT Works!');
});

router.delete('/', function(req, res) {
  res.send('Tasks Delete Works!');
});

router.patch('/', function(req, res) {
  res.send('Tasks Patch Works!');
});

module.exports = router