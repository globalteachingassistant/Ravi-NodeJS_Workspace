var axios = require('axios')

(async function() {
    var response = await axios.get('https://jsonplaceholder.typicode.com/posts/1');
    console.log('async - await', response.data);
})()

axios.get('https://jsonplaceholder.typicode.com/posts/1')
    .then(function(response) {
        return response.data;
    })
    .then(function(post) {
        console.log('promise', post);
    })
    .catch(function(err) {
        console.log('Something went wrong.');
    })

console.log('Outside everything.');

// var request = require('request');

// request('https://jsonplaceholder.typicode.com/posts/1', function(err, response, body) {
//     if(!err) {
//         console.log(response.statusCode);
//         console.log(body);
//     } else {
//         console.log(err);
//     }
// });