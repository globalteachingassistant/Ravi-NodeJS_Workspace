var Task = require('../models/Task')

exports.addTask = function(req, res) {
    res.send('Add Task Works!')
}

exports.getTasks = function(req, res) {
    var tasks = Task.find()
    res.json(tasks)
}

exports.getSingleTask = function(req, res) {
    res.send('Get Single Task Works!')
}

exports.removeTask = function(req, res) {
    res.send('Remove Task Works!')
}

exports.updateTask = function(req, res) {
    res.send('Update Task Works!')
}

exports.markAsComplete = function(req, res) {
    res.send('Mark As Complete Works!')
}