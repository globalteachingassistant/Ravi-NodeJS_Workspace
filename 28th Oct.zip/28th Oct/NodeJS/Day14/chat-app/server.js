var http = require('http')
var express = require('express')
var socketio = require('socket.io')

var app = express()
var server = http.createServer(app)
var io = socketio(server)

io.on('connection', function(socket) {
    console.log('User Connected!')
    socket.on('onClientMsg', function(msg) {
        socket.emit('onServerMsg', msg)
    })
})

app.use(express.static('public'))

server.listen(4200, function() {
    console.log('server started!')
})