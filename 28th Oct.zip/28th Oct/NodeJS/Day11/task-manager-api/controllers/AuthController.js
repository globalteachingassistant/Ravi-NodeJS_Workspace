exports.login = function(req, res) {
    res.send('New Login Works!')
}

exports.register = function(req, res) {
    res.send('New Register Works!')
}

// module.exports = {
//     login: function(req, res) {
//         res.send('New Login Works!')
//     },
//     register: function(req, res) {
//         res.send('New Register Works!')
//     }
// }