function taskValidator(req, res, next) {
    var data = req.body;
    var errors = {};
    
    if(typeof data.title === 'undefined' || data.title === '') {
        errors.title = 'Title can not be blank.';
    }
    
    if(typeof data.description === 'undefined' || data.description === '') {
        errors.description = 'Description can not be blank.';
    }
    
    if(Object.keys(errors).length === 0) {
        next();
    } else {
        res.status(400).json(errors);
    }
}

module.exports = taskValidator;