var promise = new Promise(function(resolve, reject) {
    setTimeout(function() {
        resolve({ foo: 'bar' });
    }, 3000);
});

var promise2 = new Promise(function(resolve, reject) {
    setTimeout(function() {
        resolve({ foo: 'bar123' });
    }, 3000);
});


promise.then(function(){
    console.log('Promise resolved!');
    // promise2.then(function(data) {
    //     console.log('Promise 2 resolved! ', data);
    // })
    return promise2;
}).then(function(data) {
    console.log('resolve promise 2', data)
}).catch(function(){
    console.log('Promise rejected!');
})/*.finally(function(){ //Works in some cases.
    console.log('Finally executed!');
})*/