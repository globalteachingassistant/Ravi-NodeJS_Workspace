var mongoose = require('mongoose')

mongoose.connect('mongodb://localhost:27017/test', function(err) {
    if(!err) {
        console.log('DB connected!')
    } else {
        console.log(err)
    }
})

const TaskSchema = new mongoose.Schema({
    title: String,
    description: String,
    completed: Boolean
}, {
    timestamps: true
})

const Task = new mongoose.model('task', TaskSchema)

Task.find().then((data) => {
    console.log(data)
})