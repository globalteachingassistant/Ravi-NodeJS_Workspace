require('dotenv').config();
var jwt = require('jsonwebtoken');
var jwtDecode = require('jwt-decode'); //Generally done on the client side.

//Ecryption: Usually happens on login.

var payload = {
    email: 'foo@bar.com',
    username: 'foo bar'
};

var token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1s' });

// token += 'ab';

//Decryption: Usually Authorization header of every request is decrypted and expected response is sent on
//              successful verification of the token by jwt.

setTimeout(function() {
    var decoded = jwtDecode(token);
    console.log('Decoded Token', decoded);
    
    try {
        var data = jwt.verify(token, process.env.JWT_SECRET);
        console.log('Verified Token ', data);
    } catch(e) {
        console.log('Invalid Token');
    }    
}, 5000);

