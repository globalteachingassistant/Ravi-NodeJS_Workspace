var express = require('express');
var router = express.Router();

router.get('/tasks', function(req, res) {
  res.send('Tasks GET Works!');
});

router.post('/tasks', function(req, res) {
  res.send('Tasks POST Works!');  
});

router.put('/tasks', function(req, res) {
  res.send('Tasks PUT Works!');
});

router.delete('/tasks', function(req, res) {
  res.send('Tasks Delete Works!');
});

router.patch('/tasks', function(req, res) {
  res.send('Tasks Patch Works!');
});

module.exports = router