var fs = require('fs');

fs.appendFile('./hello.txt', ' This is another test.', function(err) {
    if(!err) {
        console.log('Success!');
    }
});

// fs.writeFile('./hello.txt', 'This is a test file!', function(err) {
//   if(err)  {
//       console.log(err);
//   } else {
//       console.log('File Write Successful!!');
//   }
// });

// var buffer = fs.readFileSync('./hello.txt');
// console.log(buffer.toString())

// fs.readFile('./hello.txt', function(err, buffer) {
//     console.log(buffer.toString());
// });

console.log('Reading/Writing File.');