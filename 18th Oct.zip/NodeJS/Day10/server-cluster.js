var cluster = require('cluster');
var os = require('os');
var http = require('http');

var workers = {};

if(cluster.isMaster) {
    console.log('Inside Master process');
    var cpus = os.cpus().length;
    
    cluster.on('disconnect', function() {
        var worker = cluster.fork();
        workers[worker.process.pid] = 0;
    })
    
    cluster.on('message', function(worker, msg) {
        // if(typeof workers[worker.process.pid] === 'undefined') {
        //     workers[worker.process.pid] = 1;
        // } else {
        //     workers[worker.process.pid]++;
        // }
        switch(msg) {
            case 'Requested':
                workers[worker.process.pid]++;
                break;
            case 'Shutdown':
                worker.disconnect();
                break;
        }
        
        console.log('Message from Worker', worker.process.pid, msg);
        // console.log(workers);
    })
    
    for(var i = 0; i < cpus; i++) {
        var worker = cluster.fork();
        workers[worker.process.pid] = 0;
        worker.send('From Master');
        // worker.on('exit', function(code, signal) { //This would only work for limited processes
        //     cluster.fork();
        // });
    }
} else {
    var server = http.createServer(function(req, res) {
        process.send('Requested');
        res.end('Request addressed by process :: ' + process.pid);
        if(req.url === '/shutdown') {
            process.send('Shutdown');
        }
    });
    
    server.listen(4200, function() {
        console.log('Server Started!', process.pid)
    });
    
    process.on('message', function(msg) {
        console.log('Message', msg);
    });
}
