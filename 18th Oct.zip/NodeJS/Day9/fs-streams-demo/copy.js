var fs = require('fs');

var readStream = fs.createReadStream('../Topics.txt');
var writeStream = fs.createWriteStream('../Topics1.txt');

readStream.pipe(writeStream);

var stats = fs.statSync('../Topics.txt');

console.log(stats.size);