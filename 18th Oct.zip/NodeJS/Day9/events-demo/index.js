var events = require('events');
var http = require('http');

var eventEmitter = new events.EventEmitter();

var server = http.createServer(function(req, res) {
    eventEmitter.emit('onRequest', { q: req.url });
    res.end('Server Works!');
});

server.listen(4200, function() {
    console.log('Server Started!')
});

eventEmitter.on('onRequest', function(data) {
    console.log('The following resource was requested ::', data);
});
