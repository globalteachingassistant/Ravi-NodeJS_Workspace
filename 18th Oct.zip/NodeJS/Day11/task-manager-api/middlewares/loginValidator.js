function loginValidator(req, res, next) {
    var data = req.body;
    var errors = {};
    
    if(typeof data.username === 'undefined' || data.username === '') {
        errors.username = 'Username cannot be blank.'
    }
    
    if(typeof data.password === 'undefined' || data.password === '') {
        errors.password = 'Password cannot be blank.'
    }
    
    if(Object.keys(errors).length === 0) {
        next();
    } else {
        res.status(400).json(errors);
    }
}

module.exports = loginValidator;