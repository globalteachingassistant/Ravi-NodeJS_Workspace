var Task = function(id, title, description) {
    this.id = id;
    this.title = title;
    this.description = description;
    this.completed = false;
}

var tasks = [
    new Task(1, 'Learn NodeJS', 'This is to learn nodejs'),
    new Task(2, 'Learn MongoDB', 'This is for learning mongodb'),
    new Task(3, 'Learn Angular', 'This is for learning angular'),
    new Task(4, 'Learn HTML', 'This is for learning html')
]

exports.find = function() {
    return tasks;
}

exports.findById = function(id) {
    var task = null;
    
    for(var i in tasks) {
        if(id == tasks[i].id) {
            task = tasks[i];
            break;
        }
    }
    
    return task;
}

exports.save = function(data) {
    var newTask = new Task(
        tasks.length + 1,
        data.title,
        data.description
    );
    
    tasks.push(newTask);
    
    return newTask;
}