var dotenv = require('dotenv');
dotenv.config();

console.log('File Name', __filename);
console.log('Dir Name', __dirname);

var PORT = process.env.PORT || 3000;

console.log(PORT);