(async function() {
    var promise = new Promise(function(resolve, reject) {
        setTimeout(function() {
            resolve({ foo: 'bar' });
        }, 3000);
    });
    
    var data = await promise
    console.log(data)
    
    var promise1 = new Promise(function(resolve, reject) {
        setTimeout(function() {
            resolve({ foo: 'bar123' });
        }, 3000);
    });
    
    var data = await promise1
    console.log(data)
    
    console.log('Outside promise');    
})();