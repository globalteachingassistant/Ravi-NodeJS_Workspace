import { Component, OnInit } from '@angular/core';
import { TaskService } from 'src/app/services/task.service'
import { Task } from 'src/app/models/task'

@Component({
  selector: 'app-task-form',
  templateUrl: './task-form.component.html',
  styleUrls: ['./task-form.component.css']
})
export class TaskFormComponent implements OnInit {

  title:string = '';
  description:string = '';
  
  msg:string = '';

  constructor(private taskService: TaskService) { }

  ngOnInit() {
      
  }

  addTask(form) {
    const data = {
        title: this.title,
        description: this.description
    }
    
    this.taskService.addTask(data)
        .subscribe((newTask: Task) => {
            this.msg = 'Task Added!'
            // this.title = ''
            // this.description = ''
            form.reset();
            setTimeout(() => this.msg = '', 3000)
        })
  }
}
